﻿using System;
using System.Collections.Generic;

//secao 4

// q31
class Animal_q31
{
    public virtual string FazerSom() => "som genérico";
}
class Cachorro_q31 : Animal_q31
{
    public override string FazerSom() => "au au";
}

// q32
class Veiculo_q32
{
    public int Velocidade;
}
class Carro_q32 : Veiculo_q32
{
    public void Buzinar() { Console.WriteLine("bi bi!"); }
}

// q33
class Forma_q33
{
    public virtual double Area() => 0;
}
class Quadrado_q33 : Forma_q33
{
    public double Lado;
    public Quadrado_q33(double lado) { Lado = lado; }
    public override double Area() => Lado * Lado;
}

// q34
class Pessoa_q34
{
    public string Nome;
    public int Idade;
}
class Aluno_q34 : Pessoa_q34
{
    public double Nota;
    public void Estudar() { Console.WriteLine($"{Nome} estudando..."); }
}

// q35
class Conta_q35
{
    protected double saldo;
    public double Saldo => saldo;
}
class ContaPoupanca_q35 : Conta_q35
{
    public ContaPoupanca_q35(double inicial) { saldo = inicial; }
    public void RenderJuros() { saldo += saldo * 0.01; }
}

//q36 
class Funcionario_q36
{
    public double Salario;
    public Funcionario_q36(double s) { Salario = s; }
}
class Gerente_q36 : Funcionario_q36
{
    public double Bonus;
    public Gerente_q36(double s, double b) : base(s) { Bonus = b; }
    public double SalarioTotal() => Salario + Bonus;
}

// q37 
class Produto_q37
{
    public double Preco;
    public Produto_q37(double p) { Preco = p; }
}
class ProdutoDigital_q37 : Produto_q37
{
    public double TamanhoArquivo;
    public ProdutoDigital_q37(double p, double t) : base(p) { TamanhoArquivo = t; }
    public void Baixar() { Console.WriteLine("baixando arquivo..."); }
}

// q38 
class Transporte_q38
{
    public virtual string Mover() => "movendo";
}
class Aviao_q38 : Transporte_q38
{
    public int Altitude;
    public override string Mover() => "voando";
}

//q39
class Jogo_q39
{
    public string Nome;
}
class JogoOnline_q39 : Jogo_q39
{
    public string Servidor;
    public void Conectar() { Console.WriteLine($"conectando ao servidor {Servidor}..."); }
}

// q40 
class BibliotecaItem_q40
{
    public string Titulo;
}
class Livro_q40 : BibliotecaItem_q40
{
    public string Autor;
}
class Revista_q40 : BibliotecaItem_q40
{
    public int Edicao;
}


// testando
class Program
{
    static void Main()
    {
        Console.WriteLine("---- seção 4: herança básica ----\n");

        // q31
        Animal_q31 a = new Cachorro_q31();
        Console.WriteLine("som do cachorro: " + a.FazerSom());

        // q32
        Carro_q32 c = new Carro_q32();
        c.Velocidade = 80;
        c.Buzinar();

        // q33
        Quadrado_q33 q = new Quadrado_q33(4);
        Console.WriteLine("area quadrado: " + q.Area());

        // q34
        Aluno_q34 al = new Aluno_q34 { Nome = "Maria", Idade = 20, Nota = 9 };
        al.Estudar();

        // q35
        ContaPoupanca_q35 cp = new ContaPoupanca_q35(1000);
        cp.RenderJuros();
        Console.WriteLine("saldo poupanca: " + cp.Saldo);

        // q36
        Gerente_q36 g = new Gerente_q36(3000, 1000);
        Console.WriteLine("salario total gerente: " + g.SalarioTotal());

        // q37
        ProdutoDigital_q37 pd = new ProdutoDigital_q37(200, 500);
        pd.Baixar();

        // q38
        Aviao_q38 av = new Aviao_q38 { Altitude = 10000 };
        Console.WriteLine("aviao se move: " + av.Mover());

        // q39
        JogoOnline_q39 jo = new JogoOnline_q39 { Nome = "FIFA", Servidor = "Brasil-01" };
        jo.Conectar();

        // q40
        Livro_q40 l = new Livro_q40 { Titulo = "Dom Casmurro", Autor = "Machado de Assis" };
        Revista_q40 r = new Revista_q40 { Titulo = "Superinteressante", Edicao = 320 };
        Console.WriteLine($"livro: {l.Titulo} - {l.Autor}");
        Console.WriteLine($"revista: {r.Titulo} - edição {r.Edicao}");

        Console.WriteLine("\n---- fim da seção 4 ----");
    }
}
