﻿using System;
using System.Collections.Generic;

//secao 5

// q41
class Animal_q41
{
    public virtual void Comer() { Console.WriteLine("animal comendo"); }
}
class Mamifero_q41 : Animal_q41
{
    public override void Comer() { Console.WriteLine("mamífero comendo"); }
}
class Ave_q41 : Animal_q41
{
    public override void Comer() { Console.WriteLine("ave comendo"); }
}

// q42 
abstract class Empregado_q42
{
    public string Nome;
    public abstract double CalcularSalario();
}
class Horista_q42 : Empregado_q42
{
    public double Horas, ValorHora;
    public override double CalcularSalario() => Horas * ValorHora;
}
class Assalariado_q42 : Empregado_q42
{
    public double SalarioFixo;
    public override double CalcularSalario() => SalarioFixo;
}

// q43 
abstract class Forma_q43 { public abstract double Perimetro(); }
class Retangulo_q43 : Forma_q43
{
    public double L, A;
    public Retangulo_q43(double l, double a) { L = l; A = a; }
    public override double Perimetro() => 2 * (L + A);
}
class Circulo_q43 : Forma_q43
{
    public double R;
    public Circulo_q43(double r) { R = r; }
    public override double Perimetro() => 2 * Math.PI * R;
}

// q44
class Veiculo_q44 { public virtual void Acelerar() { Console.WriteLine("acelerando..."); } }
class Bicicleta_q44 : Veiculo_q44 { public override void Acelerar() { Console.WriteLine("pedalando..."); } }
class Moto_q44 : Veiculo_q44 { public override void Acelerar() { Console.WriteLine("acelerando com motor..."); } }

// q45
interface INadador_q45 { void Nadar(); }
interface ICorredor_q45 { void Correr(); }
class Triatleta_q45 : INadador_q45, ICorredor_q45
{
    public void Nadar() { Console.WriteLine("nadando"); }
    public void Correr() { Console.WriteLine("correndo"); }
    public void Competir() { Nadar(); Correr(); Console.WriteLine("competindo triathlon"); }
}

// q46
class Produto_q46
{
    public double Preco;
    public Produto_q46(double p) { Preco = p; }
    public virtual double CalcularPreco() => Preco;
}
class ProdutoFisico_q46 : Produto_q46
{
    public double Frete;
    public ProdutoFisico_q46(double p, double f) : base(p) { Frete = f; }
    public override double CalcularPreco() => Preco + Frete;
}
class ProdutoServico_q46 : Produto_q46
{
    public double Taxa;
    public ProdutoServico_q46(double p, double t) : base(p) { Taxa = t; }
    public override double CalcularPreco() => Preco + Taxa;
}

// q47
class Pessoa_q47 { public string Nome; }
class Cliente_q47 : Pessoa_q47 { public string CPF; }
class Fornecedor_q47 : Pessoa_q47 { public string CNPJ; }

// q48 
class Arquivo_q48 { public virtual void Abrir() { Console.WriteLine("abrindo arquivo"); } }
class ArquivoTexto_q48 : Arquivo_q48 { public override void Abrir() { Console.WriteLine("abrindo arquivo texto"); } }
class ArquivoBinario_q48 : Arquivo_q48 { public override void Abrir() { Console.WriteLine("abrindo arquivo binário"); } }

// q49 
class Conta_q49
{
    public double Saldo;
    public virtual bool Sacar(double v)
    {
        if (v <= Saldo) { Saldo -= v; return true; }
        return false;
    }
}
class ContaCorrente_q49 : Conta_q49
{
    public double Limite;
    public override bool Sacar(double v)
    {
        if (v <= Saldo + Limite) { Saldo -= v; return true; }
        return false;
    }
}
class ContaInvestimento_q49 : Conta_q49
{
    public double Rendimento;
    public void Render() { Saldo += Saldo * (Rendimento / 100.0); }
}

// q50 
interface ITelaTouch_q50 { void Tocar(int x, int y); }
class Dispositivo_q50 { public virtual void Ligar() { Console.WriteLine("ligando dispositivo..."); } }
class Smartphone_q50 : Dispositivo_q50, ITelaTouch_q50
{
    public override void Ligar() { Console.WriteLine("smartphone ligado"); }
    public void Tocar(int x, int y) { Console.WriteLine($"toque em {x},{y}"); }
}
class Tablet_q50 : Dispositivo_q50, ITelaTouch_q50
{
    public override void Ligar() { Console.WriteLine("tablet ligado"); }
    public void Tocar(int x, int y) { Console.WriteLine($"tablet toque em {x},{y}"); }
}


// testes 

class Program
{
    static void Main()
    {
        Console.WriteLine(" herança avançada e polimorfismo n");

        // q41
        List<Animal_q41> animais = new List<Animal_q41> { new Mamifero_q41(), new Ave_q41() };
        foreach (var an in animais) an.Comer();

        // q42
        Empregado_q42 h = new Horista_q42 { Nome = "João", Horas = 40, ValorHora = 25 };
        Empregado_q42 s = new Assalariado_q42 { Nome = "Ana", SalarioFixo = 3000 };
        Console.WriteLine("salário horista: " + h.CalcularSalario());
        Console.WriteLine("salário assalariado: " + s.CalcularSalario());

        // q43
        Forma_q43 f1 = new Retangulo_q43(4, 6);
        Forma_q43 f2 = new Circulo_q43(3);
        Console.WriteLine("perímetro retângulo: " + f1.Perimetro());
        Console.WriteLine("perímetro círculo: " + f2.Perimetro());

        // q44
        Veiculo_q44 v1 = new Bicicleta_q44();
        Veiculo_q44 v2 = new Moto_q44();
        v1.Acelerar();
        v2.Acelerar();

        // q45
        Triatleta_q45 t = new Triatleta_q45();
        t.Competir();

        // q46
        Produto_q46 pf = new ProdutoFisico_q46(100, 20);
        Produto_q46 ps = new ProdutoServico_q46(200, 50);
        Console.WriteLine("preço produto físico: " + pf.CalcularPreco());
        Console.WriteLine("preço serviço: " + ps.CalcularPreco());

        // q47
        Cliente_q47 cli = new Cliente_q47 { Nome = "Carlos", CPF = "123.456.789-00" };
        Fornecedor_q47 forn = new Fornecedor_q47 { Nome = "Loja X", CNPJ = "12.345.678/0001-00" };
        Console.WriteLine($"cliente: {cli.Nome}, cpf: {cli.CPF}");
        Console.WriteLine($"fornecedor: {forn.Nome}, cnpj: {forn.CNPJ}");

        // q48
        Arquivo_q48 txt = new ArquivoTexto_q48();
        Arquivo_q48 bin = new ArquivoBinario_q48();
        txt.Abrir();
        bin.Abrir();

        // q49
        ContaCorrente_q49 cc = new ContaCorrente_q49 { Saldo = 500, Limite = 200 };
        Console.WriteLine("saque corrente (600): " + cc.Sacar(600));
        ContaInvestimento_q49 ci = new ContaInvestimento_q49 { Saldo = 1000, Rendimento = 10 };
        ci.Render();
        Console.WriteLine("saldo investimento após render: " + ci.Saldo);

        // q50
        Smartphone_q50 sm = new Smartphone_q50();
        sm.Ligar();
        sm.Tocar(10, 20);

        Tablet_q50 tab = new Tablet_q50();
        tab.Ligar();
        tab.Tocar(30, 40);

        
    }
}
