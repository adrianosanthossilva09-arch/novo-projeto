﻿using System;
using System.Collections.Generic;


// seção 3


// q21
class Pessoa_q21
{
    private int _idade;
    public int Idade
    {
        get => _idade;
        set { if (value >= 0) _idade = value; }
    }
}

//q22 
class Conta_q22
{
    private double saldo = 0;
    public double Saldo => saldo;

    public void Depositar(double v)
    {
        if (v > 0) saldo += v;
    }

    public bool Sacar(double v)
    {
        if (v > 0 && v <= saldo)
        {
            saldo -= v;
            return true;
        }
        return false;
    }
}

//q23 
class Aluno_q23
{
    private double nota;
    public double Nota
    {
        get => nota;
        set { if (value >= 0 && value <= 10) nota = value; }
    }
}

// q24
class Produto_q24
{
    private double preco;
    public double Preco
    {
        get => preco;
        set { if (value >= 0) preco = value; }
    }

    public void AplicarDesconto(double percentual)
    {
        double novo = preco - (preco * percentual / 100.0);
        if (novo >= 0) preco = novo;
    }
}

// q25
class Carro_q25
{
    private int velocidade = 0;
    public int Velocidade => velocidade;

    public void Acelerar(int incremento)
    {
        velocidade += incremento;
        if (velocidade > 200) velocidade = 200;
    }
}

// q26
class Usuario_q26
{
    private string senha;
    public Usuario_q26(string senhaInicial) { senha = senhaInicial; }

    public bool Autenticar(string tentativa) => senha == tentativa;
    public void AlterarSenha(string nova) { senha = nova; }
}

// q27
class Banco_q27
{
    private List<int> contas = new List<int>();

    public void Adicionar(int id)
    {
        if (!contas.Contains(id)) contas.Add(id);
    }

    public void Remover(int id)
    {
        contas.Remove(id);
    }

    public List<int> Listar()
    {
        return new List<int>(contas);
    }
}

// q28 
class Forma_q28
{
    private double area;
    public double Area => area;

    public Forma_q28(double a)
    {
        area = a;
    }
}

// q29 
class Empregado_q29
{
    private double salario;
    public Empregado_q29(double salarioInicial) { salario = salarioInicial; }
    public double CalcularBonus() => salario * 0.10;
}

// q30
class Configuracao_q30
{
    private Dictionary<string, string> dados = new Dictionary<string, string>();

    public void Set(string chave, string valor)
    {
        dados[chave] = valor;
    }

    public string Get(string chave)
    {
        return dados.ContainsKey(chave) ? dados[chave] : null;
    }
}


//testes

class Program
{
    static void Main()
    {
        Console.WriteLine("---- seção 3: encapsulamento ----\n");

        // q21
        var p = new Pessoa_q21();
        p.Idade = 25;
        Console.WriteLine("idade pessoa: " + p.Idade);

        // q22
        var conta = new Conta_q22();
        conta.Depositar(500);
        bool saque = conta.Sacar(200);
        Console.WriteLine($"saldo: {conta.Saldo}, saque ok? {saque}");

        // q23
        var a = new Aluno_q23();
        a.Nota = 9;
        Console.WriteLine("nota aluno: " + a.Nota);

        // q24
        var prod = new Produto_q24();
        prod.Preco = 100;
        prod.AplicarDesconto(20);
        Console.WriteLine("preco produto: " + prod.Preco);

        // q25
        var c = new Carro_q25();
        c.Acelerar(250);
        Console.WriteLine("velocidade carro: " + c.Velocidade);

        // q26
        var u = new Usuario_q26("1234");
        Console.WriteLine("autenticou? " + u.Autenticar("1234"));
        u.AlterarSenha("abcd");
        Console.WriteLine("nova senha ok? " + u.Autenticar("abcd"));

        // q27
        var banco = new Banco_q27();
        banco.Adicionar(1);
        banco.Adicionar(2);
        Console.WriteLine("contas: " + string.Join(", ", banco.Listar()));

        // q28
        var f = new Forma_q28(50);
        Console.WriteLine("area forma: " + f.Area);

        // q29
        var emp = new Empregado_q29(2000);
        Console.WriteLine("bonus empregado: " + emp.CalcularBonus());

        // q30
        var cfg = new Configuracao_q30();
        cfg.Set("tema", "escuro");
        Console.WriteLine("tema configurado: " + cfg.Get("tema"));

        Console.WriteLine("\n---- fim da seção 3 ----");
    }
}
