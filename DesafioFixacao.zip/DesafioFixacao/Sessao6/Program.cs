﻿using System;

//secao 6

//q51

abstract class Forma_q51
{
    public abstract double Area();
}
class Triangulo_q51 : Forma_q51
{
    public double A, B, C;
    public Triangulo_q51(double a, double b, double c) { A = a; B = b; C = c; }
    public override double Area()
    {
        double s = (A + B + C) / 2.0;
        return Math.Sqrt(s * (s - A) * (s - B) * (s - C));
    }
}
class Retangulo_q51 : Forma_q51
{
    public double L, H;
    public Retangulo_q51(double l, double h) { L = l; H = h; }
    public override double Area() => L * H;
}

// q52 
abstract class Animal_q52 { public abstract void Mover(); }
class Peixe_q52 : Animal_q52 { public override void Mover() { Console.WriteLine("nadar"); } }
class Passaro_q52 : Animal_q52 { public override void Mover() { Console.WriteLine("voar"); } }

// q53 
abstract class Pagamento_q53 { public abstract void Processar(); }
class CartaoCredito_q53 : Pagamento_q53 { public override void Processar() { Console.WriteLine("processando cartão..."); } }
class Boleto_q53 : Pagamento_q53 { public override void Processar() { Console.WriteLine("gerando boleto..."); } }

//q54
abstract class Funcionario_q54 { public abstract double CalcularBonus(); }
class Vendedor_q54 : Funcionario_q54 { public double Vendas; public override double CalcularBonus() => Vendas * 0.05; }
class Engenheiro_q54 : Funcionario_q54 { public override double CalcularBonus() => 500; }

// q55 
abstract class Veiculo_q55 { public abstract double CalcularConsumo(); public abstract void Viajar(); }
class CarroEletrico_q55 : Veiculo_q55
{
    public override double CalcularConsumo() => 0.15;
    public override void Viajar() { Console.WriteLine("viajando com energia elétrica"); }
}
class CarroGasolina_q55 : Veiculo_q55
{
    public override double CalcularConsumo() => 8.0;
    public override void Viajar() { Console.WriteLine("viajando com gasolina"); }
}

// q56 
abstract class Estrategia_q56 { public abstract void Executar(); }
class Ataque_q56 : Estrategia_q56 { public override void Executar() { Console.WriteLine("ataque executado"); } }
class Defesa_q56 : Estrategia_q56 { public override void Executar() { Console.WriteLine("defesa executada"); } }

// q57 
abstract class Relatorio_q57 { public abstract void Gerar(); }
class RelatorioPDF_q57 : Relatorio_q57 { public override void Gerar() { Console.WriteLine("gerando pdf..."); } }
class RelatorioExcel_q57 : Relatorio_q57 { public override void Gerar() { Console.WriteLine("gerando excel..."); } }

// q58 
abstract class ItemMenu_q58 { public abstract void Preparar(); }
class PratoPrincipal_q58 : ItemMenu_q58 { public override void Preparar() { Console.WriteLine("preparando prato principal"); } }
class Sobremesa_q58 : ItemMenu_q58 { public override void Preparar() { Console.WriteLine("preparando sobremesa"); } }

// q59 
abstract class Notificador_q59 { public abstract void Enviar(string msg); }
class EmailNotificador_q59 : Notificador_q59 { public override void Enviar(string msg) { Console.WriteLine($"enviando email: {msg}"); } }
class SMSNotificador_q59 : Notificador_q59 { public override void Enviar(string msg) { Console.WriteLine($"enviando sms: {msg}"); } }

//q60 
abstract class Simulador_q60
{
    public abstract void Iniciar();
    public abstract void Executar();
    public abstract void Finalizar();
}
class SimuladorJogo_q60 : Simulador_q60
{
    public override void Iniciar() { Console.WriteLine("iniciando simulador de jogo"); }
    public override void Executar() { Console.WriteLine("executando jogo"); }
    public override void Finalizar() { Console.WriteLine("finalizando simulador de jogo"); }
}
class SimuladorTreinamento_q60 : Simulador_q60
{
    public override void Iniciar() { Console.WriteLine("iniciando simulador de treinamento"); }
    public override void Executar() { Console.WriteLine("executando treinamento"); }
    public override void Finalizar() { Console.WriteLine("finalizando simulador de treinamento"); }
}


//testes

class Program
{
    static void Main()
    {
        Console.WriteLine("---- seção 6: classes abstratas ----\n");

        // q51
        Forma_q51 f1 = new Triangulo_q51(3, 4, 5);
        Console.WriteLine("area triangulo: " + f1.Area());

        Forma_q51 f2 = new Retangulo_q51(4, 6);
        Console.WriteLine("area retangulo: " + f2.Area());

        // q52
        Animal_q52 peixe = new Peixe_q52();
        peixe.Mover();
        Animal_q52 passaro = new Passaro_q52();
        passaro.Mover();

        // q53
        Pagamento_q53 p1 = new CartaoCredito_q53();
        p1.Processar();
        Pagamento_q53 p2 = new Boleto_q53();
        p2.Processar();

        // q54
        Vendedor_q54 v = new Vendedor_q54 { Vendas = 10000 };
        Console.WriteLine("bonus vendedor: " + v.CalcularBonus());
        Engenheiro_q54 e = new Engenheiro_q54();
        Console.WriteLine("bonus engenheiro: " + e.CalcularBonus());

        // q55
        Veiculo_q55 ev = new CarroEletrico_q55();
        ev.Viajar();
        Veiculo_q55 gv = new CarroGasolina_q55();
        gv.Viajar();

        // q56
        Estrategia_q56 at = new Ataque_q56();
        Estrategia_q56 de = new Defesa_q56();
        at.Executar();
        de.Executar();

        // q57
        Relatorio_q57 r1 = new RelatorioPDF_q57();
        r1.Gerar();
        Relatorio_q57 r2 = new RelatorioExcel_q57();
        r2.Gerar();

        // q58
        ItemMenu_q58 prato = new PratoPrincipal_q58();
        prato.Preparar();
        ItemMenu_q58 doce = new Sobremesa_q58();
        doce.Preparar();

        // q59
        Notificador_q59 n1 = new EmailNotificador_q59();
        n1.Enviar("teste email");
        Notificador_q59 n2 = new SMSNotificador_q59();
        n2.Enviar("teste sms");

        // q60
        Simulador_q60 sj = new SimuladorJogo_q60();
        sj.Iniciar(); sj.Executar(); sj.Finalizar();

        Simulador_q60 st = new SimuladorTreinamento_q60();
        st.Iniciar(); st.Executar(); st.Finalizar();

        Console.WriteLine("\n---- fim da seção 6 ----");
    }
}
