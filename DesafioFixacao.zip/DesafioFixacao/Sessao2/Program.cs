﻿using System;
using System.Collections.Generic;


// seção 2

//q11 
class Retangulo_q11
{
    public double Largura;
    public double Altura;

    public Retangulo_q11(double largura, double altura)
    {
        Largura = largura;
        Altura = altura;
    }

    public double Area()
    {
        return Largura * Altura;
    }
}

//q12 
class Funcionario_q12
{
    public string Nome;
    public double Salario;

    public Funcionario_q12(string nome, double salario)
    {
        Nome = nome;
        Salario = salario;
    }

    public void AumentarSalario(double percentual)
    {
        Salario += Salario * (percentual / 100.0);
    }
}

// q13 
class Data_q13
{
    public int Dia, Mes, Ano;

    public Data_q13(int d, int m, int a)
    {
        Dia = d; Mes = m; Ano = a;
    }

    public string Formatar()
    {
        return $"{Dia:D2}/{Mes:D2}/{Ano:D4}";
    }
}

// q14
class Veiculo_q14
{
    public string Marca;
    public string Modelo;

    public Veiculo_q14(string marca, string modelo)
    {
        Marca = marca; Modelo = modelo;
    }

    public void Acelerar()
    {
        Console.WriteLine($"{Marca} {Modelo} acelerando...");
    }
}

// q15
class Triangulo_q15
{
    public double A, B, C;

    public Triangulo_q15(double a, double b, double c)
    {
        A = a; B = b; C = c;
    }

    public double Perimetro()
    {
        return A + B + C;
    }
}

//q16 
class Usuario_q16
{
    public string Nome;
    public string Email;

    public Usuario_q16(string nome, string email)
    {
        Nome = nome; Email = email;
    }

    public void AlterarEmail(string novo)
    {
        Email = novo;
    }
}

//q17 
class Biblioteca_q17
{
    private List<string> titulos = new List<string>();

    public void AdicionarLivro(string titulo)
    {
        titulos.Add(titulo);
    }

    public List<string> Listar()
    {
        return new List<string>(titulos);
    }
}

//q18 
class Calculadora_q18
{
    public double Somar(double a, double b) => a + b;
    public double Subtrair(double a, double b) => a - b;
    public double Multiplicar(double a, double b) => a * b;
    public double Dividir(double a, double b) => b == 0 ? double.NaN : a / b;
}

//q19 
class Agenda_q19
{
    private List<string> contatos;

    public Agenda_q19(List<string> contatosIniciais)
    {
        contatos = contatosIniciais ?? new List<string>();
    }

    public string BuscarContato(string nome)
    {
        foreach (var c in contatos)
        {
            if (c.IndexOf(nome, StringComparison.OrdinalIgnoreCase) >= 0)
                return c;
        }
        return null;
    }
}

// q20
class Jogo_q20
{
    public string Nome;
    public string Plataforma;

    public Jogo_q20(string nome, string plataforma)
    {
        Nome = nome; Plataforma = plataforma;
    }

    public void Jogar()
    {
        Console.WriteLine($"jogando {Nome} no {Plataforma}...");
    }
}



//testes 

class Program
{
    static void Main()
    {
        Console.WriteLine("---- seção 2: métodos e construtores ----\n");

        // q11
        var r = new Retangulo_q11(3, 5);
        Console.WriteLine("area retangulo: " + r.Area());

        // q12
        var f = new Funcionario_q12("ana", 2000);
        f.AumentarSalario(15);
        Console.WriteLine($"func: {f.Nome}, salario: {f.Salario}");

        // q13
        var d = new Data_q13(4, 9, 2025);
        Console.WriteLine("data formatada: " + d.Formatar());

        // q14
        var v = new Veiculo_q14("fiat", "uno");
        v.Acelerar();

        // q15
        var t = new Triangulo_q15(3, 4, 5);
        Console.WriteLine("perimetro triangulo: " + t.Perimetro());

        // q16
        var u = new Usuario_q16("joao", "joao@email.com");
        u.AlterarEmail("novo@email.com");
        Console.WriteLine($"usuario: {u.Nome}, email: {u.Email}");

        // q17
        var b = new Biblioteca_q17();
        b.AdicionarLivro("Clean Code");
        b.AdicionarLivro("Java: Como Programar");
        Console.WriteLine("livros na biblioteca:");
        foreach (var titulo in b.Listar()) Console.WriteLine(" - " + titulo);

        // q18
        var calc = new Calculadora_q18();
        Console.WriteLine("2 + 3 = " + calc.Somar(2, 3));
        Console.WriteLine("10 / 2 = " + calc.Dividir(10, 2));

        // q19
        var agenda = new Agenda_q19(new List<string> { "Ana - 9999", "Pedro - 8888" });
        Console.WriteLine("busca pedro: " + agenda.BuscarContato("pedro"));

        // q20
        var jogo = new Jogo_q20("FIFA", "PlayStation");
        jogo.Jogar();

    }
}
