﻿using System;

class Pessoa { } // q1

class Carro // q2
{
    public string Cor { get; set; }
    public Carro() { Cor = "vermelho"; }
}

class Animal // q3
{
    public string Nome { get; set; }
    public int Idade { get; set; }
    public Animal(string nome, int idade) { Nome = nome; Idade = idade; }
}

class Livro // q4
{
    public string Titulo { get; set; }
    public string Autor { get; set; }
    public Livro(string titulo, string autor) { Titulo = titulo; Autor = autor; }
    public void ExibirInfo() { Console.WriteLine(Titulo + " - " + Autor); }
}

class Quadrado // q5
{
    public double Lado { get; set; }
    public Quadrado(double lado) { Lado = lado; }
    public double Area() { return Lado * Lado; }
}

class Aluno // q6
{
    public string Nome { get; set; }
    public double Nota { get; set; }
    public Aluno(string nome, double nota) { Nome = nome; Nota = nota; }
}

class Circulo // q7
{
    public double Raio { get; set; }
    public Circulo(double raio) { Raio = raio; }
    public double Area() { return Math.PI * Raio * Raio; }
    public double Perimetro() { return 2 * Math.PI * Raio; }
}

class ContaBancaria // q8
{
    public double Saldo { get; private set; } = 0;
    public void Depositar(double valor) { Saldo += valor; }
}

class Produto // q9
{
    public string Nome { get; set; }
    public double Preco { get; private set; }
    public Produto(string nome, double preco) { Nome = nome; Preco = preco; }
    public void AplicarDesconto() { Preco *= 0.9; }
}

class Ponto // q10
{
    public double X { get; set; }
    public double Y { get; set; }
    public Ponto(double x, double y) { X = x; Y = y; }
    public double DistanciaOrigem() { return Math.Sqrt(X * X + Y * Y); }
}

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("seção 1 ");

        Carro c = new Carro();
        Console.WriteLine("q2: " + c.Cor);

        Animal a = new Animal("cachorro", 5);
        Console.WriteLine("q3: " + a.Nome + " - " + a.Idade);

        Livro l = new Livro("dom casmurro", "machado");
        Console.Write("q4: "); l.ExibirInfo();

        Quadrado q = new Quadrado(4);
        Console.WriteLine("q5: area=" + q.Area());

        Aluno al1 = new Aluno("ana", 8);
        Aluno al2 = new Aluno("joão", 6);
        Console.WriteLine("q6: maior nota -> " + (al1.Nota > al2.Nota ? al1.Nome : al2.Nome));

        Circulo cir = new Circulo(3);
        Console.WriteLine("q7: area=" + cir.Area() + " perimetro=" + cir.Perimetro());

        ContaBancaria cb = new ContaBancaria();
        cb.Depositar(100);
        Console.WriteLine("q8: saldo=" + cb.Saldo);

        Produto p = new Produto("camisa", 50);
        p.AplicarDesconto();
        Console.WriteLine("q9: preco=" + p.Preco);

        Ponto pt = new Ponto(3, 4);
        Console.WriteLine("q10: distancia=" + pt.DistanciaOrigem());
    }
}
